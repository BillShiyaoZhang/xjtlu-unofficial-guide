# @information-community/core

无运行时依赖的 ESM 核心包：校验社区蓝图与知识图、接纳带版本检查的提案、搜索和邻域查询。可用于 Node 22.13+、现代浏览器和支持这些 Web API 的运行环境；不依赖 SQLite、Docker、参考 UI 或任何托管商。

本版本尚未上传 npm registry。维护者在项目根运行 `npm run package:core` 后，其他项目可以独立安装产出的压缩包：

```sh
npm install ./information-community-core-0.3.0.tgz
```

```ts
import { validateGraph, searchGraph, neighborhood, type Graph } from '@information-community/core';

const graph: Graph = validateGraph(await response.json());
const matches = searchGraph(graph, { query: '新生', type: 'topic' });
const nearby = neighborhood(graph, 'arrival', 1);
```

公开函数：`validateOntology`、`validateGraph`、`safeUrl`、`makeChange`、`applyChange`、`diffGraphs`、`searchGraph`、`neighborhood`、`graphStats`、`buildBranchTree`、`branchPath`、`visibleBranchRows`；错误类型 `GraphError`。TypeScript 类型通过标准 exports 入口提供。

调用 `makeChange` 未传 ID 时，需要 `crypto.randomUUID()`；浏览器应使用 HTTPS 或 localhost。传入自己的合法提案 ID 也可避免使用随机 ID API。

Graph/Change 的 `schemaVersion` 当前为 1。只接纳 JSON 数据，包括扩展字段；函数、Date 实例、BigInt、循环引用和非有限数字会被拒绝。业务层须自行验证扩展字段的含义以及身份、证据和发布权限。

`applyChange` 先复制图，再验证完整结果；失败不修改原图。`validateGraph` 返回原对象；搜索和邻域返回对原节点/关系的引用，不会冻结数据。请勿通过修改返回引用绕过提案流程。

`diffGraphs` 只处理节点和关系的新增或替换。没有变化时会返回空 operations，调用方应提示无需提交；蓝图、社区元数据和删除操作不属于本提案协议。关系引用稳定节点 ID，尚不支持固定内容修订。

0.x 版本期间，升级前查看仓库 CHANGELOG。包与参考应用分别声明运行时要求；服务器使用 Node 24 的 SQLite API，不影响本包的使用。

## 分支与信息线索

`buildBranchTree` 接受最小图结构：节点只要求 `id`，边要求 `id/from/to/type`；保留业务扩展字段，无需 DOM 或完整 Graph v1。输入的结构会校验，业务可见性由调用方先处理。

```js
import { buildBranchTree, branchPath, visibleBranchRows } from '@information-community/core';
const tree = buildBranchTree(graph, 'arrival');
const path = branchPath(tree, 'planning');
const view = visibleBranchRows(tree, {
  expandedIds: new Set(['arrival']), selectedId: 'planning', limit: 100,
});
// tree.entries: { node, parentId, edge, depth }[]
// tree.crossEdges: 未被树采用的关联；保留原始方向及扩展字段
// tree.unreachableIds: 当前起点无法到达的节点
// view.entries / total / hasMore: 可见行、展开后的总行数、是否还有更多
```

默认沿双向邻接生成稳定的 BFS 浏览树，父子位置不改变原关系方向，也不表示因果、修订历史或真实模型上下文。多父与环不会重复生成节点，剩余关系保留为横向线索。`direction` 可选 `both` / `outgoing` / `incoming`；`relationTypes` 只限定生成树的关系，已到达节点之间的其余关系仍进入 `crossEdges`。业务有严格主路径时，应显式传入关系类型和方向。

`branchPath` 返回根到目标的条目，未到达的目标返回空数组。`visibleBranchRows` 按 DFS 输出；省略 `expandedIds` 展开全部，传空集合只显示根及选中路径。选中路径自动展开并完整保留，路径长度超过 `limit` 时允许超出该展示预算。三项函数均不修改源图，返回的节点/边仍引用输入对象。QandA 的适配与历史版本别名见仓库 `examples/qanda`。
