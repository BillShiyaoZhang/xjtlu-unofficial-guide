import { GraphError } from './index.js';

const fail = message => { throw new GraphError(message); };
const object = value => value !== null && typeof value === 'object' && !Array.isArray(value);
const id = (value, name) => {
  if (typeof value !== 'string' || !value.trim()) fail(`${name} 必须为非空字符串`);
};
const optionsObject = options => {
  if (!object(options)) fail('分支选项必须为对象');
};
function checkEdge(edge) {
  if (!object(edge)) fail('分支关系必须为对象');
  for (const key of ['id', 'from', 'to', 'type']) id(edge[key], `关系 ${key}`);
}

/**
 * Project a general directed graph into a stable breadth-first spanning tree.
 * Nodes and edges remain references to the input. No business schema is required.
 */
export function buildBranchTree(graph, rootId, options = {}) {
  optionsObject(options);
  const { direction = 'both', relationTypes } = options;
  if (!['both', 'outgoing', 'incoming'].includes(direction)) fail('分支方向必须为 both、outgoing 或 incoming');
  if (relationTypes !== undefined) {
    if (!Array.isArray(relationTypes)) fail('relationTypes 必须为非空字符串组成的数组');
    for (const type of relationTypes) id(type, '关系类型');
  }
  const allowedTypes = relationTypes === undefined ? null : new Set(relationTypes);
  if (!object(graph) || !Array.isArray(graph.nodes) || !Array.isArray(graph.edges)) fail('分支图缺少 nodes / edges 数组');
  id(rootId, '根节点 ID');
  const nodes = new Map(), neighbors = new Map(), edgeIds = new Set();
  for (const node of graph.nodes) {
    if (!object(node)) fail('分支节点必须为对象');
    id(node.id, '节点 ID');
    if (nodes.has(node.id)) fail(`节点 ID 重复：${node.id}`);
    nodes.set(node.id, node);
    neighbors.set(node.id, []);
  }
  if (!nodes.has(rootId)) fail('分支根节点不存在');
  for (const edge of graph.edges) {
    checkEdge(edge);
    if (edgeIds.has(edge.id)) fail(`关联 ID 重复：${edge.id}`);
    edgeIds.add(edge.id);
    if (!nodes.has(edge.from) || !nodes.has(edge.to)) fail('分支关系指向了不存在的节点');
    if (allowedTypes && !allowedTypes.has(edge.type)) continue;
    if (direction !== 'incoming') neighbors.get(edge.from).push({ edge, nodeId: edge.to });
    if (direction !== 'outgoing' && edge.from !== edge.to) neighbors.get(edge.to).push({ edge, nodeId: edge.from });
  }
  const entries = [{ node: nodes.get(rootId), parentId: null, edge: null, depth: 0 }];
  const reached = new Set([rootId]), treeEdges = new Set();
  for (let cursor = 0; cursor < entries.length; cursor++) {
    const parent = entries[cursor];
    for (const { edge, nodeId } of neighbors.get(parent.node.id)) {
      if (reached.has(nodeId)) continue;
      reached.add(nodeId);
      treeEdges.add(edge.id);
      entries.push({ node: nodes.get(nodeId), parentId: parent.node.id, edge, depth: parent.depth + 1 });
    }
  }
  return {
    rootId,
    entries,
    // Filters control traversal only. Keep every remaining relationship within
    // the reached set, including cycles, parallel links and other relation types.
    crossEdges: graph.edges.filter(edge => reached.has(edge.from) && reached.has(edge.to) && !treeEdges.has(edge.id)),
    unreachableIds: graph.nodes.filter(node => !reached.has(node.id)).map(node => node.id),
  };
}

function indexTree(tree) {
  if (!object(tree) || !Array.isArray(tree.entries) || !tree.entries.length) fail('分支树缺少 entries');
  id(tree.rootId, '根节点 ID');
  const byId = new Map(), children = new Map();
  for (const entry of tree.entries) {
    if (!object(entry) || !object(entry.node)) fail('分支条目必须包含节点');
    id(entry.node.id, '节点 ID');
    if (byId.has(entry.node.id)) fail(`分支节点 ID 重复：${entry.node.id}`);
    if (!Number.isSafeInteger(entry.depth) || entry.depth < 0) fail('分支深度必须为非负安全整数');
    if (entry.parentId !== null) id(entry.parentId, '父节点 ID');
    byId.set(entry.node.id, entry);
    children.set(entry.node.id, []);
  }
  if (!byId.has(tree.rootId)) fail('分支根节点不存在');
  for (const entry of tree.entries) {
    if (entry.node.id === tree.rootId) {
      if (entry.parentId !== null || entry.edge !== null || entry.depth !== 0) fail('根分支必须无父节点、无关系且深度为 0');
      continue;
    }
    const parent = byId.get(entry.parentId);
    if (!parent || entry.depth !== parent.depth + 1) fail('分支父节点或深度不合法');
    checkEdge(entry.edge);
    const { from, to } = entry.edge;
    if (!((from === parent.node.id && to === entry.node.id) || (to === parent.node.id && from === entry.node.id))) fail('分支关系未连接父子节点');
    children.get(parent.node.id).push(entry);
  }
  return { byId, children };
}

function pathFromIndex(byId, nodeId) {
  const path = [];
  let entry = byId.get(nodeId);
  while (entry) {
    path.push(entry);
    entry = entry.parentId === null ? undefined : byId.get(entry.parentId);
  }
  return path.reverse();
}

/** Return the complete root-to-node path, or [] for a node outside this tree. */
export function branchPath(tree, nodeId) {
  id(nodeId, '节点 ID');
  return pathFromIndex(indexTree(tree).byId, nodeId);
}

/**
 * Flatten expanded branches in depth-first order, keeping a selected path whole.
 * total counts expanded rows before pagination; limit may be exceeded by that path.
 */
export function visibleBranchRows(tree, options = {}) {
  optionsObject(options);
  const { expandedIds, selectedId, limit } = options;
  if (selectedId !== undefined) id(selectedId, '选中节点 ID');
  if (limit !== undefined && (!Number.isSafeInteger(limit) || limit < 0)) fail('分支行数限制必须为非负安全整数');
  let expanded;
  if (expandedIds !== undefined) {
    if (expandedIds === null || typeof expandedIds === 'string' || typeof expandedIds[Symbol.iterator] !== 'function') fail('expandedIds 必须为节点 ID 的可迭代集合');
    expanded = new Set();
    for (const nodeId of expandedIds) { id(nodeId, '展开节点 ID'); expanded.add(nodeId); }
  }
  const { byId, children } = indexTree(tree);
  const selectedPath = selectedId === undefined ? [] : pathFromIndex(byId, selectedId);
  if (expanded) for (let index = 0; index < selectedPath.length - 1; index++) expanded.add(selectedPath[index].node.id);
  const flattened = [], stack = [byId.get(tree.rootId)];
  while (stack.length) {
    const entry = stack.pop();
    flattened.push(entry);
    if (!expanded || expanded.has(entry.node.id)) {
      const descendants = children.get(entry.node.id);
      for (let index = descendants.length - 1; index >= 0; index--) stack.push(descendants[index]);
    }
  }
  const total = flattened.length;
  if (limit === undefined || total <= limit) return { entries: flattened, total, hasMore: false };
  const required = new Set(selectedPath.map(entry => entry.node.id));
  let remaining = Math.max(0, limit - required.size);
  const entries = flattened.filter(entry => {
    if (required.has(entry.node.id)) return true;
    if (remaining > 0) { remaining--; return true; }
    return false;
  });
  return { entries, total, hasMore: entries.length < total };
}
